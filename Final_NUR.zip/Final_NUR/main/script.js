var a = 0;
$(window).scroll(function() {

  var oTop = $('#counter').offset().top - window.innerHeight;
  if (a == 0 && $(window).scrollTop() > oTop) {
    $('.counter-value').each(function() {
      var $this = $(this),
        countTo = $this.attr('data-count');
      $({
        countNum: $this.text()
      }).animate({
          countNum: countTo
        },

        {

          duration: 3000,
          easing: 'swing',
          step: function() {
            $this.text(Math.floor(this.countNum));
          },
          complete: function() {
            $this.text(this.countNum);
          }

        });
    });
    a = 1;
  }

});
                $(document).ready(function() {
                    $("#img1").click(function() {
                        $("#p1").toggle(100);
                     
                    });
                    $("#img2").click(function() {
                        $("#p2").toggle(10);
                });
                $("#img3").click(function() {
                    $("#p3").toggle(10);
                 
                });
                $("#img4").click(function() {
                    $("#p4").toggle(10);
                });
            });
    
           